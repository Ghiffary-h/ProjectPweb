<?php

namespace App\Services;

class FileService
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
