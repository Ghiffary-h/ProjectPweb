<?php

namespace App\Services;

class SearchService
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
