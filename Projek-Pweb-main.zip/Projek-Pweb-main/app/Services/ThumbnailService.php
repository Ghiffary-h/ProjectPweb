<?php

namespace App\Services;

class ThumbnailService
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
