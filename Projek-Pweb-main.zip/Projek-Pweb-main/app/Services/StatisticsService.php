<?php

namespace App\Services;

class StatisticsService
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
