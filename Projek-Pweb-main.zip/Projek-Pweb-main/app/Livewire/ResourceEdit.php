<?php

namespace App\Livewire;

use Livewire\Component;

class ResourceEdit extends Component
{
    public function render()
    {
        return view('livewire.resource-edit');
    }
}
