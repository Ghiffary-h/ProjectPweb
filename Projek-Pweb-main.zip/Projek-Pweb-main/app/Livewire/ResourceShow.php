<?php

namespace App\Livewire;

use Livewire\Component;

class ResourceShow extends Component
{
    public function render()
    {
        return view('livewire.resource-show');
    }
}
