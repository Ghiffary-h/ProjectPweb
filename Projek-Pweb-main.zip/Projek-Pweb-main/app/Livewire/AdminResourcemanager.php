<?php

namespace App\Livewire;

use Livewire\Component;

class AdminResourcemanager extends Component
{
    public function render()
    {
        return view('livewire.admin-resourcemanager');
    }
}
