<?php

namespace App\Livewire;

use Livewire\Component;

class ModerationQueue extends Component
{
    public function render()
    {
        return view('livewire.moderation-queue');
    }
}
