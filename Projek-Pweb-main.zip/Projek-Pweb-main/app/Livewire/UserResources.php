<?php

namespace App\Livewire;

use Livewire\Component;

class UserResources extends Component
{
    public function render()
    {
        return view('livewire.user-resources');
    }
}
